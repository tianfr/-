package com.tanwei;

import com.tanwei.phone.MyRecord;

import java.net.SocketException;
import java.net.UnknownHostException;

public class Main {

    public static void main(String[] args) throws SocketException, UnknownHostException {

        //创造一个客户端实例
        MyRecord mr = new MyRecord();

    }

}
